import React from 'react'
import { Route } from 'react-router-dom'
import Home from '../Screens/Home'
// import Footer from '../../ComponentAdmin/Footer'
// import Header from '../../ComponentAdmin/Header'
// import SliderBar from '../../ComponentAdmin/SliderBar'
export const LayoutHeader = (props) => {
    return (
        <>

            {/* <Header />
            <SliderBar /> */}
            asdasd
            {props.children}
            {/* <Footer /> */}
            {/* START LOADER */}
            {/* </ div> */}
        </>
    )
}
export const AdminTemplate = () => {
    console.log("!23");
    return (
        <>
            {/* <Route {...rest} element={<Home />} /> */}
        </>
    )
}