import './App.css';
import RoutesMain from './routes/index';
function App() {
  return (
    <RoutesMain/>
  );
}

export default App;
